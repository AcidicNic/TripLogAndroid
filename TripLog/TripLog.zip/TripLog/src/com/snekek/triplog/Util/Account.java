package com.snekek.triplog.Util;

public class Account {
    private String username;
    private String saveLocation;

}
