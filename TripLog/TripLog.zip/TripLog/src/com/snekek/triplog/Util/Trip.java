package com.snekek.triplog.Util;

public class Trip {
    private String title;
    private Drug drug;
    private Dose dose;

    public void Trip(String title, Drug drug, Dose dose) {
        //  TODO Define Trips
    }
}
