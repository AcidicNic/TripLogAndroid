package com.snekek.triplog.Util;

public class Dose {

    private String[] units = {"μg", "mg", "g", "unknown"};

    public void Dose(int n, String unit) {

    }

    public String[] getUnits() {
        return units;
    }


}
