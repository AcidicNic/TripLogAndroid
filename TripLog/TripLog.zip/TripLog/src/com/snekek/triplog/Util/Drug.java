package com.snekek.triplog.Util;

public class Drug {

}
